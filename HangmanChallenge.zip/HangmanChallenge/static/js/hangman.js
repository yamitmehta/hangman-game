document.addEventListener('DOMContentLoaded', function() {
    // Hide the loading spinner when page is fully loaded
    const loadingSpinner = document.getElementById('loading-spinner');
    if (loadingSpinner) {
        loadingSpinner.style.display = 'none';
    }
    
    // Set up staggered animation for letter buttons
    const letterButtons = document.querySelectorAll('.letter-btn');
    letterButtons.forEach((button, index) => {
        // Set a custom property for staggered animation
        button.style.setProperty('--letter-index', index);
        
        // Add click event with animation
        button.addEventListener('click', function() {
            const letter = this.getAttribute('data-letter');
            handleLetterSelection(letter, this);
        });
    });

    // Set up event handler for keyboard input
    document.addEventListener('keydown', function(event) {
        // Check if a key from A-Z is pressed
        if (/^[a-zA-Z]$/.test(event.key)) {
            const letter = event.key.toLowerCase();
            const letterButton = document.querySelector(`.letter-btn[data-letter="${letter}"]`);
            
            if (letterButton && !letterButton.hasAttribute('disabled')) {
                // Visually indicate the key press
                animateButtonPress(letterButton);
                
                // Handle the letter selection
                handleLetterSelection(letter, letterButton);
            }
        }
    });

    // Handle letter selection
    function handleLetterSelection(letter, buttonElement) {
        // Visual feedback before submitting
        animateButtonPress(buttonElement);
        
        // Add temporary visual feedback
        buttonElement.classList.add('selecting');
        
        // Set the form input value
        document.getElementById('guessInput').value = letter;
        
        // Show loading spinner with a small delay for animation
        setTimeout(() => {
            if (loadingSpinner) {
                loadingSpinner.style.display = 'flex';
            }
            // Submit the form
            document.getElementById('guessForm').submit();
        }, 200);
    }
    
    // Button press animation
    function animateButtonPress(button) {
        button.style.transform = 'scale(1.1)';
        setTimeout(() => {
            button.style.transform = '';
        }, 150);
    }

    // Enhance revealed letters with staggered animation
    const revealedLetters = document.querySelectorAll('.revealed-letter');
    revealedLetters.forEach((letter, index) => {
        // Add delay based on position
        letter.style.animationDelay = `${index * 0.1}s`;
    });

    // Apply visual classes to used letters with improved animations
    const correctGuesses = document.querySelectorAll('.letter-btn.correct');
    correctGuesses.forEach((button, index) => {
        button.classList.add('btn-success');
        button.setAttribute('disabled', 'disabled');
        
        // Add slight delay for staggered effect
        setTimeout(() => {
            button.style.animationPlayState = 'running';
        }, index * 50);
    });

    const incorrectGuesses = document.querySelectorAll('.letter-btn.incorrect');
    incorrectGuesses.forEach((button, index) => {
        button.classList.add('btn-danger');
        button.setAttribute('disabled', 'disabled');
        
        // Add slight delay for staggered effect
        setTimeout(() => {
            button.style.animationPlayState = 'running';
        }, index * 50);
    });

    // Show game result modal if game is over with animation effect
    const gameStatus = document.getElementById('gameStatus');
    if (gameStatus && (gameStatus.value === 'won' || gameStatus.value === 'lost')) {
        // Slight delay for dramatic effect
        setTimeout(() => {
            const gameResultModal = new bootstrap.Modal(document.getElementById('gameResultModal'));
            gameResultModal.show();
            
            // Add entrance animation to modal
            const modalContent = document.querySelector('.modal-content');
            if (modalContent) {
                modalContent.style.transform = 'scale(0.8)';
                modalContent.style.opacity = '0';
                
                setTimeout(() => {
                    modalContent.style.transition = 'all 0.3s ease-out';
                    modalContent.style.transform = 'scale(1)';
                    modalContent.style.opacity = '1';
                }, 100);
            }
        }, 600);
    }
    
    // Show loading spinner when form is submitted with animation
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            if (loadingSpinner) {
                // Fade in animation
                loadingSpinner.style.opacity = '0';
                loadingSpinner.style.display = 'flex';
                
                setTimeout(() => {
                    loadingSpinner.style.transition = 'opacity 0.3s ease';
                    loadingSpinner.style.opacity = '1';
                }, 50);
            }
        });
    });
    
    // Add interactive animations for hangman parts
    const hangmanParts = document.querySelectorAll('.hangman-scaffold, .hangman-head, .hangman-body, .hangman-arms, .hangman-legs');
    hangmanParts.forEach(part => {
        part.style.animationPlayState = 'running';
    });
});

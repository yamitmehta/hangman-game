# Hangman Game

A simple but engaging web-based Hangman game built with Flask and Bootstrap.

## Features

- Three difficulty levels (Easy, Medium, Hard) with appropriate word selection
- Visual hangman display with colorful ASCII art
- Interactive on-screen keyboard with color-coded feedback
- Score calculation based on difficulty level and remaining attempts
- Responsive design that works on desktop and mobile devices
- Loading animation for smooth transitions between game states

## Technologies Used

- **Backend**: Python with Flask
- **Frontend**: HTML, CSS, JavaScript
- **Styling**: Bootstrap with Replit dark theme
- **Deployment**: Replit

## How to Play

1. Select a difficulty level (Easy: 3-4 letter words, Medium: 5-7 letter words, Hard: 8+ letter words)
2. Guess one letter at a time by clicking the on-screen keyboard or pressing keys on your physical keyboard
3. Each incorrect guess brings the hangman figure closer to completion
4. You win if you guess the word before the hangman is complete
5. You lose if the hangman drawing is completed before you guess the word
6. Your score is calculated based on the difficulty level and how many incorrect guesses you made

## Project Structure

- `app.py`: Main Flask application with routes
- `game.py`: Game logic and HangmanGame class
- `main.py`: Entry point for running the application
- `templates/`: HTML templates
- `static/`: CSS, JavaScript, and other static assets

## Getting Started

To run this project locally:

1. Clone the repository
2. Install the required packages: `pip install flask gunicorn`
3. Run the application: `python main.py`
4. Open a browser and navigate to `http://localhost:5000`

## License

MIT
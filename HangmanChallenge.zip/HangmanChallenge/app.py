import os
import logging
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from game import HangmanGame

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Word lists by difficulty
WORD_LISTS = {
    'easy': [
        'cat', 'dog', 'sun', 'map', 'hat', 'run', 'red', 'box', 'cup', 'toy',
        'ball', 'book', 'fish', 'tree', 'bird', 'cake', 'door', 'star', 'milk', 'jump'
    ],
    'medium': [
        'apple', 'water', 'house', 'river', 'music', 'beach', 'clock', 'plane',
        'shoes', 'space', 'cloud', 'plant', 'tiger', 'phone', 'money', 'bread',
        'table', 'chair', 'queen', 'night'
    ],
    'hard': [
        'astronomy', 'butterfly', 'challenge', 'discovery', 'elephant', 
        'fantastic', 'generation', 'happiness', 'important', 'knowledge',
        'language', 'mountain', 'necessary', 'opportunity', 'photograph',
        'question', 'restaurant', 'technology', 'university', 'volunteer'
    ]
}

@app.route('/')
def index():
    """Render the main page"""
    # Reset game state
    if 'game' in session:
        session.pop('game')
    
    return render_template('index.html')

@app.route('/start_game', methods=['POST'])
def start_game():
    """Start a new hangman game"""
    difficulty = request.form.get('difficulty', 'medium')
    
    # Create new game
    game = HangmanGame(WORD_LISTS[difficulty])
    
    # Save game state to session
    session['game'] = game.to_dict()
    session['score'] = 0
    session['games_played'] = 0
    
    return redirect(url_for('play_game'))

@app.route('/game')
def play_game():
    """Render the game page"""
    if 'game' not in session:
        return redirect(url_for('index'))
    
    game_state = HangmanGame.from_dict(session['game'])
    
    return render_template(
        'game.html', 
        game=game_state,
        score=session.get('score', 0),
        games_played=session.get('games_played', 0)
    )

@app.route('/guess', methods=['POST'])
def make_guess():
    """Process a guess"""
    if 'game' not in session:
        return redirect(url_for('index'))
    
    letter = request.form.get('letter', '').lower()
    
    # Validate input
    if not letter or len(letter) != 1 or not letter.isalpha():
        return redirect(url_for('play_game'))
    
    # Get current game state
    game = HangmanGame.from_dict(session['game'])
    
    # Make guess
    result = game.guess(letter)
    
    # Save updated game state
    session['game'] = game.to_dict()
    
    # Check if game is over
    if game.is_game_over():
        # Update score
        if game.is_won():
            # Score is calculated based on correct guesses and remaining attempts
            session['score'] = session.get('score', 0) + game.calculate_score()
        
        # Increment games played
        session['games_played'] = session.get('games_played', 0) + 1
    
    return redirect(url_for('play_game'))

@app.route('/new_word', methods=['POST'])
def new_word():
    """Start a new word while keeping the score"""
    if 'game' not in session:
        return redirect(url_for('index'))
    
    # Get current game state to preserve difficulty
    old_game = HangmanGame.from_dict(session['game'])
    difficulty = old_game.difficulty
    
    # Create new game
    game = HangmanGame(WORD_LISTS[difficulty])
    
    # Save game state to session
    session['game'] = game.to_dict()
    
    return redirect(url_for('play_game'))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

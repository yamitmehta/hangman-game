import random


class HangmanGame:
    """
    Represents a Hangman game instance with word selection, game state tracking,
    and score calculation.
    """
    
    # ASCII art for different hangman states with colorful elements
    HANGMAN_STATES = [
        # 0 wrong guesses
        """
<span class="hangman-scaffold">          -----
          |   |
              |
              |
              |
              |
        -------</span>
        """,
        # 1 wrong guess
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|
              |
              |
              |
        -------</span>
        """,
        # 2 wrong guesses
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|</span>
<span class="hangman-body">          |</span>   <span class="hangman-scaffold">|
              |
              |
        -------</span>
        """,
        # 3 wrong guesses
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|</span>
<span class="hangman-arms">         /|</span>   <span class="hangman-scaffold">|
              |
              |
        -------</span>
        """,
        # 4 wrong guesses
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|</span>
<span class="hangman-arms">         /|\\</span>  <span class="hangman-scaffold">|
              |
              |
        -------</span>
        """,
        # 5 wrong guesses
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|</span>
<span class="hangman-arms">         /|\\</span>  <span class="hangman-scaffold">|</span>
<span class="hangman-legs">         /</span>    <span class="hangman-scaffold">|
              |
        -------</span>
        """,
        # 6 wrong guesses (game over)
        """
<span class="hangman-scaffold">          -----
          |   |</span>
<span class="hangman-head">          O</span>   <span class="hangman-scaffold">|</span>
<span class="hangman-arms">         /|\\</span>  <span class="hangman-scaffold">|</span>
<span class="hangman-legs">         / \\</span>  <span class="hangman-scaffold">|
              |
        -------</span>
        """
    ]
    
    MAX_WRONG_GUESSES = len(HANGMAN_STATES) - 1
    
    def __init__(self, word_list):
        """Initialize a new Hangman game with a random word from the provided list"""
        self.word = random.choice(word_list).lower()
        self.guessed_letters = set()
        self.wrong_guesses = 0
        self.is_won_flag = False
        self.is_lost_flag = False
        
        # Determine difficulty based on word length
        if len(self.word) <= 4:
            self.difficulty = 'easy'
        elif len(self.word) <= 7:
            self.difficulty = 'medium'
        else:
            self.difficulty = 'hard'
    
    def guess(self, letter):
        """Process a guess and update game state"""
        # Convert to lowercase
        letter = letter.lower()
        
        # If the game is over or the letter has already been guessed, do nothing
        if self.is_game_over() or letter in self.guessed_letters:
            return False
        
        # Add letter to guessed letters
        self.guessed_letters.add(letter)
        
        # Check if the letter is in the word
        if letter in self.word:
            # Check if the player has won
            if all(l in self.guessed_letters for l in self.word):
                self.is_won_flag = True
            return True
        else:
            # Increment wrong guesses counter
            self.wrong_guesses += 1
            
            # Check if the player has lost
            if self.wrong_guesses >= self.MAX_WRONG_GUESSES:
                self.is_lost_flag = True
            return False
    
    def get_hidden_word(self):
        """Return the word with unguessed letters hidden"""
        return ''.join(
            letter if letter in self.guessed_letters else '_' 
            for letter in self.word
        )
    
    def get_hangman_display(self):
        """Return the ASCII art for the current state"""
        return self.HANGMAN_STATES[self.wrong_guesses]
    
    def is_game_over(self):
        """Check if the game is over"""
        return self.is_won() or self.is_lost()
    
    def is_won(self):
        """Check if the player has won"""
        return self.is_won_flag
    
    def is_lost(self):
        """Check if the player has lost"""
        return self.is_lost_flag
    
    def get_unused_letters(self):
        """Return the list of unused letters"""
        alphabet = 'abcdefghijklmnopqrstuvwxyz'
        return [letter for letter in alphabet if letter not in self.guessed_letters]
    
    def calculate_score(self):
        """Calculate score based on difficulty, correct guesses, and remaining attempts"""
        if not self.is_won():
            return 0
        
        # Base score based on difficulty
        difficulty_multiplier = {
            'easy': 1,
            'medium': 2,
            'hard': 3
        }
        
        # Calculate score
        base_score = len(set(self.word)) * 10  # Points for unique letters in the word
        difficulty_bonus = difficulty_multiplier.get(self.difficulty, 1) * 20
        attempts_bonus = (self.MAX_WRONG_GUESSES - self.wrong_guesses) * 15
        
        return base_score + difficulty_bonus + attempts_bonus
    
    def to_dict(self):
        """Convert game state to dictionary for session storage"""
        return {
            'word': self.word,
            'guessed_letters': list(self.guessed_letters),
            'wrong_guesses': self.wrong_guesses,
            'is_won_flag': self.is_won_flag,
            'is_lost_flag': self.is_lost_flag,
            'difficulty': self.difficulty
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create a game instance from dictionary data"""
        game = cls(['dummy'])  # Create a dummy instance
        game.word = data['word']
        game.guessed_letters = set(data['guessed_letters'])
        game.wrong_guesses = data['wrong_guesses']
        game.is_won_flag = data['is_won_flag']
        game.is_lost_flag = data['is_lost_flag']
        game.difficulty = data['difficulty']
        return game
